const User = require('../models/professores');
const Joi = require('joi');

const professoresSchema = Joi.object({
  name: Joi.string().required(),
  email: Joi.string().email().required()
});

exports.getAllProfessores = async (req, res) => {
    const professores = await User.findAll();
    res.json(professores);
  };;